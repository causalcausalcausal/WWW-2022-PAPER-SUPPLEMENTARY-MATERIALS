How to run this code in shell command:

In build folder, run:


rm -r *
cmake ..
make
./MBCF

Then, you can see the result on the screen.
#############################################
main entrance for this c++ project:

/core/main.cpp


you can modify the input data as you like.


